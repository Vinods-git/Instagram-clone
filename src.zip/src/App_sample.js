import React from 'react';

const App_sample = (props) => {
  return (
    <div>
    	VInod
    </div>
  )
}

export default App_sample;